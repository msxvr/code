For all the files of ZIP:<br>
*Attribution-NonCommercial-NoDerivs 3.0 Unported*<br>
[LICENSE-SUMMARY](https://creativecommons.org/licenses/by-nc-nd/3.0/)<br>
[LICENSE-LEGAL CODE](https://creativecommons.org/licenses/by-nc-nd/3.0/legalcode)<br>


